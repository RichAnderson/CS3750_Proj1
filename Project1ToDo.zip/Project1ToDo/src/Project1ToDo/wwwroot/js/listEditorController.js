﻿//listEditorController.js

(function () {
    "use strict";

    angular.module("app-lists")
        .controller("listEditorController", listEditorController)

    function listEditorController($routeParams, $http) {
        var vm = this;
        vm.listName = $routeParams.listName;
        vm.lists = [];
        vm.errorMessage = "";
        vm.isBusy = true;
        vm.newListItem = {};

        var url = "/api/lists/" + vm.listName + "/items";

        $http.get(url)
            .then(function (response) {
                //success
                angular.copy(response.data, vm.lists);
            }, function (err) {
                vm.errorMessage = "Failed to load event detail data";
            })
            .finally(function () {
                vm.isBusy = false;
            });

        vm.addListItem = function () {
            vm.isBusy = true;

            $http.post(url, vm.newListItem)
                .then(function (response) {
                    //success
                    vm.lists.push(response.data);
                    vm.newListItem = {};
                }, function (err) {
                    //failure
                    vm.errorMessage = "Failed to post new event details";
                })
                .finally(function () {
                    vm.isBusy = false;
                });
        };
    }

})();