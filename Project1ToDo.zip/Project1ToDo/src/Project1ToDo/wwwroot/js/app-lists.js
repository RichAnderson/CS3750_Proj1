﻿//app-lists.js

(function () {
    "use strict";

    angular.module("app-lists", ["simpleControls", "ngRoute"])
        .config(function ($routeProvider) {

            $routeProvider.when("/", {
                controller: "listsController",
                controllerAs: "vm",
                templateUrl: "/views/listView.html"
            });

            $routeProvider.when("/editor/:listName", {
                controller: "listEditorController",
                controllerAs: "vm",
                templateUrl: "/views/listEditorView.html"
            });

            $routeProvider.otherwise({ redirectTo: "/" });

        });


})();