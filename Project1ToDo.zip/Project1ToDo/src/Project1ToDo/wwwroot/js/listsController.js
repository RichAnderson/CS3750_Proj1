﻿//listsController.js
(function () {

    "use strict";

    //Getting the existing module
    angular.module("app-lists")
        .controller("listsController", listsController);

    function listsController($http) {

        var vm = this;

        vm.lists = [];

        vm.newList = {};

        vm.errorMessage = "";
        vm.isBusy = true;

        $http.get("/api/lists")
            .then(function (response) {
                //Success
                angular.copy(response.data, vm.lists);
                vm.isBusy = false;
            }, function () {
                //Failure
                vm.errorMessage = "Failed to load data";
            })
            .finally(function () {
                vm.isBusy = false;
            });

        vm.addList = function () {
            vm.isBusy = false;
            vm.errorMessage = "";

            $http.post("/api/lists", vm.newList)
                .then(function (response) {
                    //Success
                    vm.events.push(response.data);
                    vm.newList = {};
                }, function () {
                    //Failure
                    vm.errorMessage = "Failed to save new event";
                })
                .finally(function () {
                    vm.isBusy = false;
                });
        };

    }

})();