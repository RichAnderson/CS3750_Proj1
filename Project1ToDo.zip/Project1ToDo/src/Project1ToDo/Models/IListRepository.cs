﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Project1ToDo.Models
{
    public interface IListRepository
    {
        IEnumerable<List> GetAllLists();
        List GetListByName(string listName);

        void AddList(List list);
        void AddItem(string listName, Item newItem);

        IEnumerable<Category> FetchCategories(string listName);

        Task<bool> SaveChangesAsync();

    }


}