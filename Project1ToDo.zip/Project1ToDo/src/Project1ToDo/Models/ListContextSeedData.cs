﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1ToDo.Models
{
    public class ListContextSeedData
    {
        private ListContext _context;

        public ListContextSeedData(ListContext context)
        {
            _context = context;
        }

        public async Task EnsureSeedData()
        {
            if (!_context.Lists.Any())
            {
                var newList1 = new List()
                {
                    listName = "Test List",
                    dateCreated = DateTime.Now,
                    Items = new List<Item>()
                    {
                        new Item() {itemName="Item 1", dateCreated = DateTime.Now, completed = false },
                        new Item() {itemName="Item 2", dateCreated = DateTime.Now, completed = false },
                        new Item() {itemName="Item 3", dateCreated = DateTime.Now, completed = false },
                        new Item() {itemName="Item 4", dateCreated = DateTime.Now, completed = false }
                    }
                };

                _context.Lists.Add(newList1);
                _context.Items.AddRange(newList1.Items);

                var newList2 = new List()
                {
                    listName = "Second List",
                    dateCreated = DateTime.Now,
                    Items = new List<Item>
                    {
                        new Item() {itemName="Item 1", dateCreated = DateTime.Now, completed = false },
                        new Item() {itemName="Item 2", dateCreated = DateTime.Now, completed = false },
                        new Item() {itemName="Item 3", dateCreated = DateTime.Now, completed = false },
                        new Item() {itemName="Item 4", dateCreated = DateTime.Now, completed = false },
                        new Item() {itemName="Item 5", dateCreated = DateTime.Now, completed = false },
                        new Item() {itemName="Item 6", dateCreated = DateTime.Now, completed = false }
                    }
                };

                _context.Lists.Add(newList2);
                _context.Items.AddRange(newList2.Items);

                //var category1 = new Category()
                //{
                //    categoryName = "Shopping",
                //    creationDate = DateTime.Now,
                //};

                //_context.Categories.Add(category1);

                //var category2 = new Category()
                //{
                //    categoryName = "To Do List",
                //    creationDate = DateTime.Now
                //};

                //_context.Categories.Add(category2);

                //var category3 = new Category()
                //{
                //    categoryName = "Misc",
                //    creationDate = DateTime.Now
                //};

                //_context.Categories.Add(category3);

                await _context.SaveChangesAsync();
            }
        }
    }
}
