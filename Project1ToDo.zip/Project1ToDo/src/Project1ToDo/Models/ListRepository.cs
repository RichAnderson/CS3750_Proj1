﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1ToDo.Models
{
    public class ListRepository : IListRepository
    {
        private ListContext _context;

        public ListRepository(ListContext context)
        {
            _context = context;
        }

        public void AddItem(string listName, Item newItem)
        {
            var list = GetListByName(listName);

            if (list != null)
            {
                //The Foreign key is being set on the item for the list
                list.Items.Add(newItem);
                //Now it is being add to the database
                _context.Items.Add(newItem);
            }
        }

        public void AddList(List list)
        {
            _context.Add(list);
        }

        public IEnumerable<Category> FetchCategories(string listName)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<List> GetAllLists()
        {
            return _context.Lists.ToList();
        }

        public List GetListByName(string listName)
        {
            return _context.Lists
                .Include(i => i.Items)
                .Where(l => l.listName == listName)
                .FirstOrDefault();
        }

        public async Task<bool> SaveChangesAsync()
        {
            return (await _context.SaveChangesAsync()) > 0;
        }
    }
}
