﻿using Microsoft.Extensions.Logging;
using Project1ToDo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1ToDo.Services
{
    public class CollectCategories
    {
        private ILogger<CollectCategories> _logger;
        private IListRepository _repo;

        public CollectCategories(ILogger<CollectCategories> logger, IListRepository repo)
        {
            _logger = logger;
            _repo = repo;
        }

        public CategoryResults GetCategories(string listName)
        {
            var results = new CategoryResults()
            {
                Success = false,
                Message = "Failed to retrieve the corresponding categories"
            };

            var cat = _repo.FetchCategories(listName);

            return results;
        }
    }
}
