﻿using Project1ToDo.Models;
using System.Collections.Generic;

namespace Project1ToDo.Services
{
    public class CategoryResults
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public ICollection<Category> Categories { get; set; }
    }
}