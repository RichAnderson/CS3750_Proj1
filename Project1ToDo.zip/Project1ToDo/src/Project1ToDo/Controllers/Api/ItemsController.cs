﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Project1ToDo.Models;
using Project1ToDo.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1ToDo.Controllers.Api
{
    [Route("api/lists/{listName}/items")]
    public class ItemsController : Controller
    {
        private ILogger<ItemsController> _logger;
        private IListRepository _repo;

        public ItemsController(IListRepository repo, ILogger<ItemsController> logger)
        {
            _repo = repo;
            _logger = logger;
        }

        [HttpGet("")]
        public IActionResult Get(string listName)
        {
            try
            {
                var list = _repo.GetListByName(listName);

                return Ok(Mapper.Map<IEnumerable<ItemViewModel>>(list.Items.OrderBy(i => i.order).ToList()));
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to get items: {ex}");
            }

            return BadRequest("Failed to get items");
        }

        [HttpPost("")]
        public async Task<IActionResult> Post(string listName, [FromBody]ItemViewModel vm)
        {
            try
            {
                var newItem = Mapper.Map<Item>(vm);
                if (ModelState.IsValid)
                {
                    _repo.AddItem(listName, newItem);
                    if (await _repo.SaveChangesAsync())
                    { 
                    return Created($"/api/lists/{listName}/items/{newItem.itemName}",
                        Mapper.Map<ItemViewModel>(newItem));
                    }
                }
            }
            catch(Exception ex)
            {
                _logger.LogError($"Failed to post new item to list: {ex}");
            }

            return BadRequest("Failed to post new item for list to the database.");
        }
    }
}
