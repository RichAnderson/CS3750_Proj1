﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Project1ToDo.Models;
using Project1ToDo.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1ToDo.Controllers.Api
{
    [Route("api/lists")]
    public class ListsController : Controller
    {
        private ILogger<ListsController> _logger;
        private IListRepository _repo;

        public ListsController(IListRepository repo, ILogger<ListsController> logger)
        {
            _repo = repo;
            _logger = logger;
        }

        [HttpGet("")]
        public IActionResult Get()
        {
            //This returns the data from the database as List objects
            //This returns a list of List Objects so you need to use a structure like
            //IEnumerable to contain them as you see in the Mapper function
            try
            {
                var results = (_repo.GetAllLists());
                //This returns the ListViewModel structure to be displayed
                //The View Model can be adjusted to allow for whatever object you want displayed
                return Ok(Mapper.Map<IEnumerable<ListViewModel>>(results));
            }
            catch (Exception ex)
            {
                //Logging Needed
                _logger.LogError($"Failed to retrieve list data from database: {ex}");

                return BadRequest(ex.Message);
            }
        }

        [HttpPost("")]
        public async Task<IActionResult> Post([FromBody]ListViewModel theList)
        {
            if (ModelState.IsValid)
            {
                //Save to the Database

                var newList = Mapper.Map<List>(theList);
                _repo.AddList(newList);

                if (await _repo.SaveChangesAsync())
                {
                    //returning the ListViewModel protects the internal structure of the object
                    //Returning the viewmodel allows to simple see how it will be displayed
                    //you can change the ListViewModel to include whatever you need to display
                    return Created($"api/lists/{theList.listName}", Mapper.Map<ListViewModel>(newList));
                }
                else
                {
                    _logger.LogError($"Failed to save data to the database");

                    return BadRequest(ModelState);
                }
            }

            return BadRequest("Failed to save the list");
        }        
    }
}
