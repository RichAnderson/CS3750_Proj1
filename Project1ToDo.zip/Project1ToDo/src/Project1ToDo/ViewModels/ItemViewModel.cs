﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1ToDo.ViewModels
{
    public class ItemViewModel
    {
        [Required]
        [StringLength(100, MinimumLength = 5)]
        public string itemName { get; set; }
        public int order { get; set; }
        public DateTime dateCreated { get; set; } = DateTime.Now;
        public DateTime dateCompleted { get; set; }
        public bool completed { get; set; }
    }
}
