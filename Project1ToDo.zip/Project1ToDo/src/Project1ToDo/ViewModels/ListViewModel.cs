﻿using Project1ToDo.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1ToDo.ViewModels
{
    public class ListViewModel
    {
        [Required]
        [StringLength(100,MinimumLength = 5)]
        public string listName { get; set; }
        public DateTime dateCreated { get; set; } = DateTime.Now;

        public ICollection<Category> categories { get; set; }
    }
}
